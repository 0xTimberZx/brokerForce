# BrokerForce

A protocol-agnostic Liquidity Intelligence Platform that helps liquidity providers discover, evaluate, and optimize concentrated liquidity opportunities across DeFi.

This repository is built **docs-first**. Before reading any code, read:

1. [`docs/Vision.md`](docs/Vision.md) — what BrokerForce is and why it exists.
2. [`docs/Product_Principles.md`](docs/Product_Principles.md) — the rules every feature is held to, including the one that matters most: nothing gets coded until it can be explained in one sentence.
3. [`docs/Roadmap.md`](docs/Roadmap.md) — the Year/Phase plan, and the actual engineering build order (they're not the same thing — see §4 of that doc).
4. [`docs/Architecture.md`](docs/Architecture.md) — system layers, data models, and the architectural decisions made so far (including the ones still open).
5. [`specs/`](specs/) — one numbered spec per feature, each the development checklist for that feature before any code traces back to it.

`docs/ORT.md`, `docs/Analytics.md`, `docs/Database.md`, and `docs/API.md` go deeper on the scoring engine, metric methodology, schema, and endpoint contracts respectively. `docs/Glossary.md` defines every term used across all of the above.

## Status

This is a scaffold, not a built product. All docs are currently at **Draft** status, pending a batch approval pass. The monorepo wires together correctly (shared types, stubbed API routes matching every endpoint in `docs/API.md`, a minimal React/Tailwind shell) but contains no real business logic yet — every route returns `501 not implemented` on purpose, so it's obvious what's a contract and what's an implementation.

## Structure

```
docs/        — the constitution (Phase 0)
specs/       — numbered feature specs (Phase 1)
apps/api     — Express/TypeScript API, stubbed routes per docs/API.md
apps/web     — React/TypeScript/Vite/Tailwind app, scaffold-only
packages/types — shared TypeScript types, mirrors docs/Database.md
```

## Getting Started

```bash
npm install
npm run dev:api   # API on :4000
npm run dev:web   # Web app via Vite
```

## Contributing

Every change should trace back to a spec in `specs/`. If you're about to write code and can't point to which spec it implements, that's the actual next step — not the code. See `docs/Product_Principles.md` §4 for the full Define → Design → Build discipline this project runs on.
